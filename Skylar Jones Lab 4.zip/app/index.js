
import React from 'react'
import App from '../App';
const Index = () => {
    return (
      
      <App/>
      
    );
  
    
  };
  
  export default Index